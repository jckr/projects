var data={series:"Access to sanitation", label:"People with no access to sanitation", label_size:20 ,values:[
{key:1990, value:2347.39324, population:5289.445444, percentage:0.443788156027345, legend:""},
{key:2010, value:2446.18003, population:6907.377783, percentage:0.354140182692828, legend:"Despite heavy investments over the last 20 years, the number of people without access to sanitation has slightly increased in absolute terms."},
{key:2030, value:2021.947324, population:8307.37085799999, percentage:0.243391965829101, legend:""},
{key:2050, value:1360.732457, population:9150.45710922, percentage:0.148706500752725, legend:""}]};
