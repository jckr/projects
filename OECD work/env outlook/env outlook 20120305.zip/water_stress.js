var data={series:"People living under severe water stress", label:"Population under severe water stress", label_size:16 ,values:[
{key:2000, value:1608.27259295, population:6086.95698074, percentage:0.264216191775103, legend:""},
{key:2050, value:3895.37749603, population:9150.45710922, percentage:0.425703049534544, legend:"In 2050, over 40% of the world population, or nearly 4 billion people, will live in areas under severe water stress (where water demand exceeds 40% of water supply)"}]};
