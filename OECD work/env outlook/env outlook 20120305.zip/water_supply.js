var data={series:"Access to water", label:"No improved water supply", label_size:16,tabs:[1990,2010,2030,2050] ,values:[
{key:1990, value:1040.84786, population:5289.445444, percentage:0.196778257951534, legend:""},
{key:2010, value:829.397508, population:6907.377783, percentage:0.120074148838545, legend:"Despite heavy investments over the last 20 years, the number of people without access to improved water supply hasn't decreased significantly."},
{key:2030, value:445.617838, population:8307.37085799999, percentage:0.0536412597459605, legend:""},
{key:2050, value:242.354647, population:9150.45710922, percentage:0.0264855235216395, legend:""}]};
