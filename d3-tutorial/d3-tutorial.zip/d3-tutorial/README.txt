
These files prepared for the “Introduction to Data Visualization on the Web with D3.js” tutorial at VisWeek 2012 by organizers Jérôme Cukier, Jeff Heer, and Scott Murray.

Sample code written primarily by Jeff, with alterations by Scott.

Use as you see fit!

–SM, October 12, 2012
