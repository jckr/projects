var data=[	
{country:"France",cat1:"Charges salarié", cat2:"Sécurité Sociale",cat3:"Maladie, Maternité, Inv, Décès",value:600,dots:19}	,
{country:"France",cat1:"Charges salarié", cat2:"Sécurité Sociale",cat3:"Vieillesse plafonnée",value:2418.738,dots:76}	,
{country:"France",cat1:"Charges salarié", cat2:"Sécurité Sociale",cat3:"Vieillesse déplafonnée",value:80,dots:3}	,
{country:"France",cat1:"Charges salarié", cat2:"Chômage",cat3:"Chômage TA/TB",value:1920,dots:60}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"Retraite ARRCO TA ",value:1091.16,dots:34}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"Retraite AGIRC TB ",value:3359.356,dots:105}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"AGFF TA",value:290.976,dots:9}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"AGFF TB",value:392.652,dots:12}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"APEC TA",value:8.72928,dots:0}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"APEC TB",value:10.47072,dots:0}	,
{country:"France",cat1:"Charges salarié", cat2:"Retraite complémentaire",cat3:"CET",value:104,dots:3}	,
{country:"France",cat1:"Charges salarié", cat2:"Autres ",cat3:"CSGS imposable (b. 98,25%)",value:2279.4,dots:71}	,
{country:"France",cat1:"Charges salarié", cat2:"Autres ",cat3:"CSG déductible (b. 98,25%)",value:4008.6,dots:125}	,
{country:"France",cat1:"Charges salarié", cat2:"Autres ",cat3:"CSGS imposable (sans abat)",value:15.82182,dots:0}	,
{country:"France",cat1:"Charges salarié", cat2:"Autres ",cat3:"CSG déductible (sans abat)",value:27.82458,dots:1}	,
{country:"France",cat1:"IR", cat2:"IR",cat3:"IR français à payer",value:4260,dots:133}	,
//{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Maladie, Maternité, Inv, Décès",value:10240,dots:320}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Maladie, Mat, Inv, Décès",value:10240,dots:320}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Contribution solidarité",value:240,dots:8}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"AT",value:960,dots:30}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Vieillesse plafonnée",value:3018.876,dots:94}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Vieillesse déplafonnée",value:1280,dots:40}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Allocations Familiales",value:4320,dots:135}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"FNAL 0,1%",value:36.372,dots:1}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"FNAL 0,4%",value:145.488,dots:5}	,
{country:"France",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"FNAL 0,5%",value:218.14,dots:7}	,
{country:"France",cat1:"Charges employeur", cat2:"Chômage",cat3:"Chômage TA/TB",value:3200,dots:100}	,
{country:"France",cat1:"Charges employeur", cat2:"Chômage",cat3:"AGS",value:240,dots:8}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"Retraite ARRCO TA ",value:1636.74,dots:51}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"Retraite AGIRC TB ",value:5497.128,dots:172}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"AGFF TA",value:436.464,dots:14}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"AGFF TB",value:567.164,dots:18}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"APEC TA",value:13.09392,dots:0}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"APEC TB",value:15.70608,dots:0}	,
{country:"France",cat1:"Charges employeur", cat2:"Retraite complémentaire",cat3:"CET",value:176,dots:6}	,
//{country:"France",cat1:"Charges employeur", cat2:"Prévoyance décès, inv., incapacité",cat3:"Prévoyance TA cadres obligatoire",value:545.58,dots:17}	,
{country:"France",cat1:"Charges employeur", cat2:"Prévoyance décès, inv., incapacité",cat3:"Prév. TA cadres obl.",value:545.58,dots:17}	,
{country:"France",cat1:"Charges employeur", cat2:"Autres ",cat3:"Taxe apprentissage",value:544,dots:17}	,
{country:"France",cat1:"Charges employeur", cat2:"Autres ",cat3:"Formation continue",value:1280,dots:40}	,
{country:"France",cat1:"Charges employeur", cat2:"Autres ",cat3:"Effort construction",value:360,dots:11}	,
{country:"France",cat1:"Charges employeur", cat2:"Autres ",cat3:"Forfait social",value:43.6464,dots:1}	,
{country:"Allemagne",cat1:"Charges salarié", cat2:"Sécurité Sociale",cat3:"Maladie/Maternité",value:3644.9,dots:114}	,
{country:"Allemagne",cat1:"Charges salarié", cat2:"Sécurité Sociale",cat3:"Assurance dépendance ",value:433.3875,dots:14}	,
{country:"Allemagne",cat1:"Charges salarié", cat2:"Sécurité Sociale",cat3:"Vieillesse, invalidité, décès",value:5731.2,dots:179}	,
{country:"Allemagne",cat1:"Charges salarié", cat2:"Chômage",cat3:"Assurance chômage",value:864,dots:27}	,
{country:"Allemagne",cat1:"IR", cat2:"IR",cat3:"IR allemand à payer",value:11500.8977254667,dots:359}	,
{country:"Allemagne",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Maladie/Maternité",value:3244.85,dots:101}	,
{country:"Allemagne",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Assurance dépendance ",value:433.3875,dots:14}	,
{country:"Allemagne",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"AT",value:1200,dots:38}	,
{country:"Allemagne",cat1:"Charges employeur", cat2:"Sécurité Sociale",cat3:"Vieillesse, invalidité, décès",value:5731.2,dots:179}	,
{country:"Allemagne",cat1:"Charges employeur", cat2:"Chômage",cat3:"Assurance chômage",value:864,dots:27}];

var countries=["France","Allemagne"];
var cats=["Charges salarié","Charges employeur","IR"];
var nbPerRow=30;

data.forEach(function(d) {d.dots=d.value*nbPerRow*nbPerRow/80000});
countries.forEach(function(c) {
	cats.forEach(function(t) {
		data.filter(function(d) {
			return d.country==c&&d.cat1==t
		}).forEach(function(d,i) {
			d.id=i
		;})
	})
})

 
var svg=d3.selectAll("#chart").append("svg:svg").attr("height",600);

var chargesE=countries.map(function(c) {return d3.sum(data.filter(function(d) {return d.country==c&&d.cat1==cats[1]}),function(d) {return d.dots;});})
var net=countries.map(function(c) {return (nbPerRow*nbPerRow)-d3.sum(data.filter(function(d) {return d.country==c&&d.cat1==cats[0]}),function(d) {return d.dots;});})

function path(value,k) {
	if(k===undefined) {k=1;}
	var myCoords=[[-k,-k],[-k,Math.ceil(value/nbPerRow)],[value%nbPerRow+k,Math.ceil(value/nbPerRow)],[value%nbPerRow+k,Math.floor(value/nbPerRow)],[k+nbPerRow-1,Math.floor(value/nbPerRow)],[k+nbPerRow-1,-k]];
	if(Math.ceil(value%nbPerRow)==nbPerRow){
	myCoords=[[-k,-k],[-k,Math.ceil(value/nbPerRow)],[nbPerRow+k-1,Math.ceil(value/nbPerRow)],[nbPerRow+k-1,-k]];}
	return d3.svg.line().x(function(d) {return xS(d[0]);}).y(function(d) {return yS(d[1]);})(myCoords)+"Z";
}

var cursor=net.slice();
var dotsData=countries.map(function(c,j) {return d3.range(nbPerRow*nbPerRow+chargesE[j]).map(function(i) {return {y:~~(i/nbPerRow),x:i%nbPerRow,class:"net"};});})

var h=600,w1=250,r=3,h1=h-250, wc=200;

var xS=d3.scale.linear().domain([0,nbPerRow-1]).range([10+r,10+w1-r]);
var x=function(d) {return xS(d.x);}

var yS=d3.scale.linear().domain([0,nbPerRow-1]).range([h-r-10,h1+r-10]);
var y=function(d) {return yS(d.y);}


d3.selectAll("#chFrance, #chAllemagne").style("top",yS(nbPerRow)+5);
d3.selectAll("#chEFrance, #chEAllemagne").style("top",0);

d3.selectAll("#chFrance, #chEFrance").style("left",100);
d3.selectAll("#chAllemagne, #chEAllemagne").style("left",1050);

CS=countries.map(function(c) {return data.filter(function(d) {
    return d.country == c && d.cat1 =="Charges salarié";
});})

CS.forEach(function(c,k) {
	c.forEach(function(d, j) {
	    dotsData[k].filter(function(dot, i) {
		return i >= cursor[k] && i < cursor[k] + d.dots
	    }).forEach(function(dot) {
		dot.class = "CS" + k + "-" + j;
	    });
	    cursor[k] += d.dots;
	   // console.log(j+" "+d.dots+" "+cursor[k]);
	})
;})

CE=countries.map(function(c) {return data.filter(function(d) {
    return d.country == c && d.cat1 =="Charges employeur";
});})

CE.forEach(function(c,k) {
	c.forEach(function(d, j) {
	    dotsData[k].filter(function(dot, i) {
		return i >= cursor[k] && i < cursor[k] + d.dots
	    }).forEach(function(dot) {
		dot.class = "CE" + k + "-" + j;
		dot.y+=1;
	    });
	    cursor[k] += d.dots;
	   // console.log(j+" "+d.dots+" "+cursor[k]);
	})
;})

var France=svg.append("svg:g").attr("transform","translate("+wc+",0)");
var Germany=svg.append("svg:g").attr("transform","translate("+(w1+wc+50)+",0)");

var listCharges=[];
listCharges[0]=France.append("svg:g").attr("transform","translate(-20, "+yS(nbPerRow)+")")
.style("text-transform","uppercase")
.style("font-weight","normal");
listCharges[0].append("svg:g").classed("salarie",1);listCharges[0].append("svg:g").classed("employeur",1);
listCharges[0].append("svg:line").classed("separator",1).attr("x1",-5).attr("y1",0).attr("y2",0).attr("x2",-wc).style("stroke","#575757").style("stroke-width",2)
listCharges[1]=Germany.append("svg:g").attr("transform","translate(-20, "+yS(nbPerRow)+")")
.style("text-transform","uppercase")
.style("font-weight","normal");
listCharges[1].append("svg:g").classed("salarie",1);listCharges[1].append("svg:g").classed("employeur",1);
listCharges[1].append("svg:line").classed("separator",1).attr("x1",50+w1).attr("y1",0).attr("y2",0).attr("x2",50+wc+w1).style("stroke","#575757").style("stroke-width",2)
svg.selectAll(".separator").style("opacity",0);

var fs1=fs2,fs2="14px";

var dots=[];

dots[0]=France.selectAll(".s").data(dotsData[0]).enter().append("svg:circle")
	.attr("cx",-wc-2*r).attr("cy",y).attr("r",4)
	.attr("class", function(d) {
	if(d.class[1]=="E")
		{return "CE "+d.class;}
	else if(d.class[1]=="S") 
		{return "CS "+d.class;}
	else {return d.class;}
	}).transition().duration(500).ease("elastic").delay(function(d,i) {return i/2;})
		.attr("cx",function(d) {
	if (d.class[1]!="E") {
		return x(d)
	;} else {
		return -wc-2*r
	;}
})

dots[1]=Germany.selectAll(".s").data(dotsData[1]).enter().append("svg:circle")
	.attr("cx",2*(w1+r)).attr("cy",y).attr("r",4)
	.attr("class", function(d) {
		if(d.class[1]=="E")
			{return "CE "+d.class;}
		else if(d.class[1]=="S") 
			{return "CS "+d.class;}
		else {return d.class;}
	}).transition().duration(500).ease("elastic").delay(function(d,i) {return i/2;})
		.attr("cx",function(d) {
	if (d.class[1]!="E") {
		return x(d)
	;} else {
		return 2*(w1+r)
	;}
})
	


d3.selectAll("circle").style("fill",function(d) {if(d.class=="net"){return "rgb(250, 104, 116)";}else if(d.class[1]=="E") {return "rgb(95, 69, 148)";} else return "rgb(250, 104, 116)";}).style("stroke","none");

oCF=France.append("svg:path").attr("d",path(nbPerRow*nbPerRow)).style("stroke","silver").style("stroke-dasharray","6 6").style("stroke-width",3).style("fill","none");
oCG=Germany.append("svg:path").attr("d",path(nbPerRow*nbPerRow)).style("stroke","silver").style("stroke-dasharray","6 6").style("stroke-width",3).style("fill","none");

netFC=France.append("svg:path").attr("d",path(net[0])).style("stroke","rgb(250, 104, 116)").style("fill","none").style("stroke-width",3).style("visibility","hidden");
netFT=France.append("svg:text").text("Salaire net: 65,815").attr("x",xS(nbPerRow/2)).attr("y",yS(~~(net[0]/nbPerRow)+2)).attr("text-anchor","middle").style("fill","rgb(250, 104, 116)").style("font-size",fs1).style("visibility","hidden");
coutEFC=France.append("svg:path").attr("d",path(nbPerRow*nbPerRow+nbPerRow+chargesE[0]-1)).style("stroke","rgb(95, 69, 148)").style("fill","none").style("stroke-width",3).style("visibility","hidden");
coutEFT=France.append("svg:text").text("Coût pour l'employeur: 115,014").attr("x",xS(nbPerRow/2)).attr("y",yS(~~(chargesE[0]/nbPerRow)+nbPerRow+3)).attr("text-anchor","middle").style("fill","#575757").style("font-size",fs1).style("visibility","hidden");

netAC=Germany.append("svg:path").attr("d",path(net[1])).style("stroke","rgb(250, 104, 116)").style("fill","none").style("stroke-width",3).style("visibility","hidden");
netAT=Germany.append("svg:text").text("Salaire net: 66,327").attr("x",xS(nbPerRow/2)).attr("y",yS(~~(net[1]/nbPerRow)+2)).attr("text-anchor","middle").style("fill","rgb(250, 104, 116)").style("font-size",fs1).style("visibility","hidden");
coutEAC=Germany.append("svg:path").attr("d",path(nbPerRow*nbPerRow+nbPerRow+chargesE[1])).style("stroke","rgb(95, 69, 148)").style("fill","none").style("stroke-width",3).style("visibility","hidden");
coutEAT=Germany.append("svg:text").text("Coût pour l'employeur: 91,473").attr("x",xS(nbPerRow/2)).attr("y",yS(~~(chargesE[1]/nbPerRow)+nbPerRow+3)).attr("text-anchor","middle").style("fill","#575757").style("font-size",fs1).style("visibility","hidden");

titreF=France.append("svg:text").text("France").attr("x",xS(nbPerRow/2)).attr("y",150).attr("text-anchor","middle").style("fill","#575757").style("font-size","36px");
titreA=Germany.append("svg:text").text("Allemagne").attr("x",xS(nbPerRow/2)).attr("y",150).attr("text-anchor","middle").style("fill","#575757").style("font-size","36px");


var slider1Val=0;
var slider2Val=0;

slider1=d3.selectAll("#salarie");
slider1.property("value",function() {return this.value;})
slider1.on("mouseup",function() {drawNet(this.value);})

slider2=d3.selectAll("#employeur");
slider2.property("value",function() {return this.value;})
slider2.on("mouseup",function() {drawCh(this.value);})



var myData,nbData,iMax,li;
function drawNet(newIndex) {
	var CSl=CS.map(function(d) {return d.length;})

	newIndex=parseFloat(newIndex);
	var myCF=d3.selectAll("#chFrance");
	var myCA=d3.selectAll("#chAllemagne");

	CS.forEach(function(c,j) {
		c.filter(function(d,i) {return (i>=((100-newIndex)*CSl[j]*.01));}).forEach(function(d,i) {
			console.log(j+"-"+d.id+": "+d3.selectAll(".CS"+j+"-"+d.id)[0].length);
			d3.selectAll(".CS"+j+"-"+d.id)
			.style("fill","silver")
			.transition()
			.duration(1000)
			.attr("cy",function() {return Math.random()*h;})
			.attr("cx",function() {return j?2*(w1+r):-wc-2*r;})
			.delay(function(dot,k){return k;})
		;})
	;})

	myData=data.filter(function(d) {return d.country=="France"&&d.cat1=="Charges salarié";})
	nbData=myData.length;

	myData=myData.filter(function(d,i) {return i<.01*nbData*newIndex;})
	iMax=myData.length;

	listCharges[0].selectAll(".salarie").selectAll("text").data(myData).enter().append("svg:text")
		.text(function(d) {return d.cat3+" "+d.value.toFixed(0);})
		.attr("text-anchor","end")
		.attr("x",15)
		.attr("y",function(d,i) {return 13*i+15;})
		.style("fill","#fa6873").style("font-size",fs1)
	.transition().delay(300).duration(500).style("fill","#575757").style("font-size",fs2);
	listCharges[0].selectAll(".salarie").selectAll("text").filter(function(d,i) {return i>=iMax;}).remove();
	
	listCharges[0].selectAll("line").transition().style("opacity",(myData.length&&data.filter(function(d,i) {return d.country=="France"&&d.cat1=="Charges employeur";}).length*slider2Val>100)?1:0);

	myData=data.filter(function(d) {return d.country=="Allemagne"&&d.cat1=="Charges salarié";})
	nbData=myData.length;
	
	myData=myData.filter(function(d,i) {return i<.01*nbData*newIndex;})
	iMax=myData.length;
	
	listCharges[1].selectAll(".salarie").selectAll("text").data(myData).enter().append("svg:text")
			.text(function(d) {return d.cat3+" "+d.value.toFixed(0);})
			//.attr("text-anchor","end")
			.attr("x",w1+50)
			.attr("y",function(d,i) {return 13*i+15;})
			.style("fill","#fa6873").style("font-size",fs1)
		.transition().delay(300).duration(500).style("fill","#575757").style("font-size",fs2);
	listCharges[1].selectAll(".salarie").selectAll("text").filter(function(d,i) {return i>=iMax;}).remove();
	
	listCharges[1].selectAll("line").transition().style("opacity",(myData.length&&data.filter(function(d,i) {return d.country=="Allemagne"&&d.cat1=="Charges employeur";}).length*slider2Val>100)?1:0);
	slider1Val=newIndex;


	CS.forEach(function(c,j) {
		c.filter(function(d,i) {return (i<(100-newIndex)*CSl[j]*.01);}).forEach(function(d,i) {
			d3.selectAll(".CS"+j+"-"+d.id).transition().attr("cy",y).attr("cx",x).style("fill","rgb(250, 104, 116)");
		;})
	;})

	if(newIndex==100){netFT.style("visibility","visible");netFC.style("visibility","visible");
	netAT.style("visibility","visible");netAC.style("visibility","visible");}
	else {netFT.style("visibility","hidden");netFC.style("visibility","hidden");
	netAT.style("visibility","hidden");netAC.style("visibility","hidden");}

}

function drawCh(newIndex) {
newIndex=parseFloat(newIndex);
	var CEl=CE.map(function(d) {return d.length;})
	
	newIndex=parseFloat(newIndex);
	var myCF=d3.selectAll("#chFrance");
	var myCA=d3.selectAll("#chAllemagne");

	CE.forEach(function(c,j) {
		c.filter(function(d,i) {return (i>=((newIndex)*CEl[j]*.01));}).forEach(function(d,i) {
			console.log(j+"-"+d.id+": "+d3.selectAll(".CE"+j+"-"+d.id)[0].length);
			d3.selectAll(".CE"+j+"-"+d.id)
			.style("fill","silver")
			.transition()
			.duration(1000)
			.attr("cy",function() {return Math.random()*h;})
			.attr("cx",function() {return j?2*(w1+r):-wc-2*r;})
			.delay(function(dot,k){return k;})
		;})
		
		c.filter(function(d,i) {return (i<(newIndex)*CEl[j]*.01);}).forEach(function(d,i) {
			d3.selectAll(".CE"+j+"-"+d.id).transition().attr("cy",y).attr("cx",x).style("fill","rgb(95, 69, 148)");
		;})
	;})
	
	myData=data.filter(function(d) {return d.country=="France"&&d.cat1=="Charges employeur";})
	 nbData=myData.length;

	myData=myData.filter(function(d,i) {return i<.01*nbData*newIndex;})
	 iMax=myData.length;

	listCharges[0].selectAll(".employeur").selectAll("text").data(myData).enter().append("svg:text")
			.text(function(d) {return d.cat3+" "+d.value.toFixed(0);})
			.attr("text-anchor","end")
			.attr("x",15)
			.attr("y",function(d,i) {return -13*i-10;})
			.style("fill","#604592").style("font-size",fs1)
		.transition().delay(300).duration(500).style("fill","#575757").style("font-size",fs2);
	listCharges[0].selectAll(".employeur").selectAll("text").filter(function(d,i) {return i>=iMax;}).remove();

	listCharges[0].selectAll("line").transition().style("opacity",(myData.length&&data.filter(function(d,i) {return d.country=="France"&&d.cat1=="Charges salarié";}).length*slider1Val>100)?1:0);

	myData=data.filter(function(d) {return d.country=="Allemagne"&&d.cat1=="Charges employeur";})
	nbData=myData.length;

	myData=myData.filter(function(d,i) {return i<.01*nbData*newIndex;})
	iMax=myData.length;

	listCharges[1].selectAll(".employeur").selectAll("text").data(myData).enter().append("svg:text")
				.text(function(d) {return d.cat3+" "+d.value.toFixed(0);})
				//.attr("text-anchor","end")
				.attr("x",w1+50)
				.attr("y",function(d,i) {return -13*i-10;})
				.style("fill","#604592").style("font-size",fs1)
			.transition().delay(300).duration(500).style("fill","#575757").style("font-size",fs2);
	listCharges[1].selectAll(".employeur").selectAll("text").filter(function(d,i) {return i>=iMax;}).remove();
	
	listCharges[1].selectAll("line").transition().style("opacity",(myData.length&&data.filter(function(d,i) {return d.country=="Allemagne"&&d.cat1=="Charges salarié";}).length*slider1Val>100)?1:0);
	
	if(newIndex==100){coutEFT.style("visibility","visible");coutEFC.style("visibility","visible");
		coutEAT.style("visibility","visible");coutEAC.style("visibility","visible");}
		else {coutEFT.style("visibility","hidden");coutEFC.style("visibility","hidden");
		coutEAT.style("visibility","hidden");coutEAC.style("visibility","hidden");}

	slider2Val=newIndex;
}
